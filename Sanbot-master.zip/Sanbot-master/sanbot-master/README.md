# sanbot
Sanbot Elf Template App

This is an empty ready to go template.

This App is empty but every libs and piece of code in the manifest and build and mainActivity is already in place.

Implements your own code, without getting stuck in imports.
